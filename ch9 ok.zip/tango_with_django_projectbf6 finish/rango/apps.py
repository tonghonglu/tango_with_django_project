from django.apps import AppConfig


class RangoConfig(AppConfig):
    name = 'rango'
